package piecesEchiquier;

public class Cavalier extends Piece {
	
	public Cavalier(String c, String emp,char l)
	{
		super(c, emp,l);
	}
}
