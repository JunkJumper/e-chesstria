package piecesEchiquier;

public class Fou extends Piece {
	
	public Fou(String c, String emp,char l) {
		super(c, emp,l);
	}
	

}
