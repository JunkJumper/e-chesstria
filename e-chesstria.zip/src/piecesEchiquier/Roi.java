package piecesEchiquier;

public class Roi extends Piece {
	
	public Roi(String c, String emp, char l) {
		super(c, emp,l);
	}
	
}
