package piecesEchiquier;

public class Pion extends Piece {
	
	public Pion(String c, String emp,char l) {
		super(c,emp,l);
	}
	
	

}
