package piecesEchiquier;

public class Reine extends Piece {
	
	public Reine(String c, String emp,char l) {
		super(c, emp,l);
	}
}
