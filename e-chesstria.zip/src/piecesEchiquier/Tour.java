package piecesEchiquier;

public class Tour extends Piece {
	

	public Tour(String c, String emp, char l) {
		super(c, emp,l);
	}

}
